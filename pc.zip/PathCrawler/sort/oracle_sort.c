void oracle_sort(
  int *Pre_table, int *table, 
  int Pre_l, int l)
{
  /* A remplacer par un vrai verdict */
  pathcrawler_verdict_unknown();

  return;
}
