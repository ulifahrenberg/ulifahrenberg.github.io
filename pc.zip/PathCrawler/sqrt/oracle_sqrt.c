void oracle_sqrt(
  int Pre_a, int a, 
  int pathcrawler__retres__sqrt)
{
  int i = pathcrawler__retres__sqrt;

  if (i*i <= a && a < (i+1) *(i+1)){
	  pathcrawler_verdict_success();
	  
	  }else{
		   pathcrawler_verdict_failure();
	   }
   

  return;
  
}