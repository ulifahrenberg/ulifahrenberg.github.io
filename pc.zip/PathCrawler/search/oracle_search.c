void oracle_search(
  int *Pre_A, int *A, 
  int Pre_n, int n,
  int Pre_elem, int elem, 
  int pathcrawler__retres__search)
{
  int res = pathcrawler__retres__search;

  /* A remplacer par un vrai verdict */
  pathcrawler_verdict_unknown();

  return;
}
